<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="panel panel-default">
                <div class="panel-heading"><h1 class="font_title">អរគុណដែលបានចុះឈ្មោះរួច</h1></div>
                <div class="panel-body">
                    <p>សូមប្អនៗចូលទៅកាន់ Link <a href="<?php echo e(url('https://www.facebook.com/ceoinstitute2014/')); ?>">CEO INSTITUTE</a> </p>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>