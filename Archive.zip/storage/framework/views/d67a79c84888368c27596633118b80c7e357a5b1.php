<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<?php echo Form::open(['method' => 'POST', 'route' => 'storeproduct', 'class' => 'form-horizontal']); ?>

		<div class="col-md-3">
					   		 	<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
					        		<?php echo Form::label('name', 'ឈ្មោះ'); ?>

					        		<?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'Name']); ?>

					        		<small class="text-danger"><?php echo e($errors->first('name')); ?></small>
					    		</div>
					   		</div>
					   		<div class="col-md-3">
					   		 	<div class="form-group<?php echo e($errors->has('detail') ? ' has-error' : ''); ?>">
					        		<?php echo Form::label('detail', 'អក្សរឡាតាំង'); ?>

					        		<?php echo Form::text('detail', null, ['class' => 'form-control', 'required' => 'required']); ?>

					        		<small class="text-danger"><?php echo e($errors->first('detail')); ?></small>
					    		</div>
					   		</div>

					   		<div class="col-md-12">
		   		<div class="btn-group pull-right">
		        	<?php echo Form::reset("Reset", ['class' => 'btn btn-warning']); ?>

		        	<?php echo Form::submit("Submit", ['class' => 'btn btn-success']); ?>

		    	</div>
		   	</div>
		<?php echo Form::close(); ?>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>