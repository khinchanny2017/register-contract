<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2><a href="<?php echo e(route('create')); ?>">ពាក្យចូលរៀន នឹងកិច្ចសន្យា</a></h2>
            </div>
            
        </div>
    </div>


    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <table class="table table-bordered">
        <tr>
            <th>លរ</th>
            <th>ឈ្មោះ</th>
            <th>ភេទ</th>
            <th>ទូរស័ព្ទ</th>
            <th>ទីកន្លែងកំណើត</th>
            <th>អត្ថសញ្ញណប័ណ្ណ</th>
            <th>ស្នាក់នៅបច្ចុប្បន្ន</th>
            <th>FB ID</th>
            <th>មកពីវិទ្យាល័យ</th>
            <th>កម្រិតវប្បធម៌</th>
            <th>និទ្ទេស</th>
            <th>ពត៌មានលំអិត</th>
        </tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($product->id); ?></td>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->gender); ?></td>
            <td><?php echo e($product->phone_number); ?></td>
            <td><?php echo e($product->p_city); ?></td>
            <td><?php echo e($product->id_number); ?></td>
            <td><?php echo e($product->c_city); ?></td>
            <td><?php echo e($product->fb_id); ?></td>
            <td><?php echo e($product->from_school); ?></td>
            <td><?php echo e($product->edu_level); ?></td>
            <td><?php echo e($product->grade); ?></td>


            <td>
                <form action="#" method="POST">

                    <a class="btn btn-sm btn-info" href="<?php echo e(route('show')); ?>">Show</a> 
                    

                    <?php echo csrf_field(); ?>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout-frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>