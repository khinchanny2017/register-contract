@extends('frontend.layout.app')

@section('content')

    <div class="container">
        <div class="row">
            <div class="panel panel-default">
                <div class="panel-heading"><h1 class="font_title">អរគុណដែលបានចុះឈ្មោះរួច</h1></div>
                <div class="panel-body">
                    <p>សូមប្អនៗចូលទៅកាន់ Link <a href="{{ url('https://www.facebook.com/ceoinstitute2014/') }}">CEO INSTITUTE</a> </p>
                </div>
            </div>
        </div>
    </div>

@endsection()