<?php
namespace App\Helpers;
class CeoHelper
{
	public static function Hello()
	{
		$option = 10;

		return $option;
	}
}